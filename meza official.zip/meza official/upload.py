from flask import Flask, request
from flask_uploads import UploadSet, configure_uploads, IMAGES

app = Flask(__name__)
uploads = UploadSet('uploads', IMAGES)
configure_uploads(app, uploads)

@app.route('/upload', methods=['GET', 'POST'])
def upload():
    
if request.method == 'POST':
        file = request.files['file']
        filename = secure_filename(file.filename)
        file.save(os.path.join(app.config['movies'], filename))
        return 'File uploaded successfully'
    return render_template('upload.html')

if __name__ ==

app.run()
